# 🚀 Bazari API

Backend do ecossistema Bazari - Fastify + Prisma + PostgreSQL

## 📋 Setup

### 1. Configurar variáveis de ambiente

```bash
cp apps/api/.env.example apps/api/.env